# Nova TV Launcher (Android)

Bu proje gerçek Android ana ekranı (HOME launcher) olarak çalışacak şekilde hazırlanmıştır.

## Derleme
1. Android Studio'da bu klasörü açın.
2. Android SDK 35 ve JDK 17 kurulu olsun.
3. Gradle senkronizasyonunu tamamlayın.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
5. APK çıktısı `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.

## Telefona kurma
1. APK'yı Android telefona yükleyin.
2. Ana ekran tuşuna basın.
3. Android'in uygulama seçicisinde **Nova TV Launcher** seçin.
4. İsterseniz "Her zaman" seçeneğiyle varsayılan ana ekran yapın.
   Varsayılan uygulama seçimi telefon üreticisine göre Ayarlar > Uygulamalar > Varsayılan uygulamalar > Ana ekran uygulaması bölümünde de bulunabilir.

## Özellikler
- Android HOME/DEFAULT intent-filter
- Cihazda başlatılabilir uygulamaları PackageManager ile listeleme
- Gerçek uygulama simgeleri ve isimleri
- Uygulama arama ve başlatma
- Saat/tarih, koyu TV tarzı arayüz
- Telefon ve geniş ekranlar için uyarlanabilir 2/4 sütunlu görünüm

## Not
Bu teslimat Android Studio kaynak projesidir, derlenmiş APK değildir. Bu çalışma ortamında Android SDK/Gradle derleme zinciri bulunmadığından burada APK derlenip imzalanamıyor. Android Studio ile debug APK oluşturulabilir. Google Play'e dağıtılacak sürüm için ayrıca release anahtarıyla imzalama ve hedef SDK/politika kontrolleri gerekir.
