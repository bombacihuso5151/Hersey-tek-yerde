package com.nova.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 13, 28)
    private val panel = Color.rgb(20, 30, 51)
    private val accent = Color.rgb(112, 214, 255)
    private lateinit var grid: GridLayout
    private lateinit var search: EditText
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var count: TextView
    private var apps: List<AppEntry> = emptyList()

    data class AppEntry(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() or
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        buildUi()
        loadApps()
        updateClock()
        val handler = android.os.Handler(mainLooper)
        val tick = object : Runnable {
            override fun run() { updateClock(); handler.postDelayed(this, 30_000) }
        }
        handler.post(tick)
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "N"; textSize = 23f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(5, 16, 29)); typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(accent, Color.rgb(123, 114, 255))).apply { cornerRadius = dp(15).toFloat() }
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(46))
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        brand.addView(text("NOVA", 19f, Color.WHITE, true))
        brand.addView(text("SMART TV LAUNCHER", 10f, Color.rgb(155, 169, 196), true))
        header.addView(logo); header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val timeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        clock = text("--:--", 25f, Color.WHITE, true)
        date = text("", 11f, Color.rgb(155, 169, 196))
        timeBox.addView(clock); timeBox.addView(date)
        header.addView(timeBox)
        page.addView(header)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(23), dp(23), dp(23), dp(23))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(23, 48, 77), Color.rgb(35, 31, 67))).apply { cornerRadius = dp(24).toFloat() }
        }
        val eyebrow = text("EV EKRANIN", 11f, accent, true)
        hero.addView(eyebrow)
        val headline = text("Her şey tek ekranda.", 29f, Color.WHITE, true)
        headline.setPadding(0, dp(9), 0, dp(7))
        hero.addView(headline)
        hero.addView(text("Yüklü uygulamalarına tek dokunuşla ulaş.", 13f, Color.rgb(190, 205, 225)))
        val heroParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(25); bottomMargin = dp(22) }
        page.addView(hero, heroParams)

        val section = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        section.addView(text("Uygulamalar", 18f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        count = text("Yükleniyor", 12f, Color.rgb(155, 169, 196))
        section.addView(count)
        page.addView(section)
        search = EditText(this).apply {
            hint = "Uygulama ara..."
            setHintTextColor(Color.rgb(130, 147, 174))
            setTextColor(Color.WHITE)
            textSize = 14f
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(15), 0, dp(15), 0)
            background = rounded(panel, dp(13).toFloat())
        }
        page.addView(search, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(14); bottomMargin = dp(14) })
        grid = GridLayout(this).apply { columnCount = if (resources.configuration.screenWidthDp >= 600) 4 else 2 }
        page.addView(grid)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderApps(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })
        val footer = text("NOVA LAUNCHER  •  Ana ekranını özelleştir", 10f, Color.rgb(120, 137, 163))
        footer.gravity = Gravity.CENTER
        page.addView(footer, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(16) })
    }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        apps = resolved.mapNotNull { info ->
            try {
                AppEntry(
                    info.loadLabel(packageManager).toString(),
                    info.activityInfo.packageName,
                    info.loadIcon(packageManager)
                )
            } catch (_: Exception) { null }
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase(Locale.getDefault()) }
        renderApps("")
    }

    private fun renderApps(filter: String) {
        if (!::grid.isInitialized) return
        grid.removeAllViews()
        val filtered = apps.filter { it.label.contains(filter, true) }
        count.text = "${filtered.size} uygulama"
        val columns = if (resources.configuration.screenWidthDp >= 600) 4 else 2
        grid.columnCount = columns
        filtered.forEach { app ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(15), dp(8), dp(13))
                background = rounded(panel, dp(18).toFloat())
                isClickable = true
                isFocusable = true
                foreground = selectableItemBackground
                setOnClickListener { launch(app.packageName) }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(app.icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            tile.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
            val label = text(app.label, 13f, Color.WHITE, true)
            label.gravity = Gravity.CENTER
            label.maxLines = 2
            label.ellipsize = android.text.TextUtils.TruncateAt.END
            tile.addView(label, LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(10) })
            val lp = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(116)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(5), dp(5), dp(5), dp(5))
            }
            grid.addView(tile, lp)
        }
        if (filtered.isEmpty()) {
            val empty = text("Eşleşen uygulama bulunamadı.", 13f, Color.LTGRAY)
            grid.addView(empty)
        }
    }

    private fun launch(packageName: String) {
        try {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) startActivity(intent)
            else Toast.makeText(this, "Bu uygulama doğrudan açılamıyor.", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Uygulama açılamadı.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateClock() {
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(now)
        date.text = SimpleDateFormat("EEEE, d MMMM", Locale("tr", "TR")).format(now)
    }

    private val selectableItemBackground: android.graphics.drawable.Drawable?
        get() {
            val attrs = intArrayOf(android.R.attr.selectableItemBackground)
            val ta = obtainStyledAttributes(attrs)
            val d = ta.getDrawable(0)
            ta.recycle()
            return d
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
